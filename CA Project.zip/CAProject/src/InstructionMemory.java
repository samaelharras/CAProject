import java.util.ArrayList;

public class InstructionMemory {
	
	public ArrayList<Short> instructionMemory;
	
	public InstructionMemory(){
		instructionMemory = new ArrayList<>(1024);
		for(int i = 0; i < 1024; i++)
			instructionMemory.add(null);
	}
	
	public void displayInstructions(){
		for(int i = 0; i < instructionMemory.size(); i++)
			System.out.println("Instruction " + i + " = " + instructionMemory.get(i));
	}
}
