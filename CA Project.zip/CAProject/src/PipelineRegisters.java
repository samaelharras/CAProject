import java.lang.reflect.Array;
import java.util.ArrayList;


public class PipelineRegisters {
	
	public ArrayList<short[]> pipelineRegisters;

	public PipelineRegisters() {
		this.pipelineRegisters = new ArrayList<>(6);
		for(int i = 0; i < 6; i++)
			pipelineRegisters.add(null);
	}

}
