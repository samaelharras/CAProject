package exceptions;

public class InvalidImmediateValueException extends Exception{
	
	public InvalidImmediateValueException() {
		super();
	}

	public InvalidImmediateValueException(String s) {
		super(s);
	}
}
