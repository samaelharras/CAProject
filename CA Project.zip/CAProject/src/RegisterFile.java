import java.util.ArrayList;

public class RegisterFile {
	
	public ArrayList<Byte> registerFile;

	public RegisterFile() {
		this.registerFile = new ArrayList<>(64);
		for(int i = 0; i < 64; i++)
			registerFile.add((byte) 0);
	}

	public void displayRegisters(){
		for(int i = 0; i < registerFile.size(); i++)
			System.out.println("R" + i + " = " + registerFile.get(i));
	}
}
