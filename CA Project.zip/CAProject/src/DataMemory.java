import java.util.ArrayList;

public class DataMemory {
	
	public ArrayList<Byte> dataMemory;
	
	public DataMemory(){
		dataMemory = new ArrayList<>(2048);
		for(int i = 0; i < 2048; i++)
			dataMemory.add((byte) 0);
	}
	
	public void displayData(){
		for(int i = 0; i < dataMemory.size(); i++)
			System.out.println("Data Address " + i + " = " + dataMemory.get(i));
	}
}
