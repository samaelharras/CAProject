import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

import exceptions.*;

public class CPU{
	
	static short pc = 0;
	static byte SREG = 0;
	InstructionMemory instructions;
	DataMemory data;
	RegisterFile registers;
	ArrayList<String> currentProgram;
	int numberOfInstructions;
	PipelineRegisters pipeline;
	
	public CPU() {
		this.instructions = new InstructionMemory();
		this.data = new DataMemory();
		this.registers = new RegisterFile();
		this.currentProgram = new ArrayList<String>();
		for(int i = 0; i < instructions.instructionMemory.size(); i++)
			currentProgram.add("");
		this.numberOfInstructions = 0;
		this.pipeline = new PipelineRegisters();
	}

	public void readFile(String program) throws InvalidRegisterException{		
		try {
			File myObj = new File(program);
			Scanner myReader = new Scanner(myObj);
			while (myReader.hasNextLine()){
				String data = myReader.nextLine();
				currentProgram.set(numberOfInstructions, data);
				String[] splitLine = data.split("\\s+");
				/*for(int i = 0; i < splitLine.length; i++)
					System.out.println(splitLine[i]);*/
				Short opcode, R1, R2, immediate;
				Short instruction = 0;
				
				//for splitLine[0] = operation, getting opcode
				switch(splitLine[0]){
				case "ADD": opcode = 0;break;
				case "SUB": opcode = 1;break;
				case "MUL": opcode = 2;break;
				case "LDI": opcode = 3; break;
				case "BEQZ": opcode = 4;break;
				case "AND": opcode = 5;break;
				case "OR": opcode = 6;break;
				case "JR": opcode = 7;break;
				case "SLC": opcode = 8;break;
				case "SRC": opcode = 9;break;
				case "LB": opcode = 10;break;
				case "SB": opcode = 11;break;
				default: opcode = 0;
				}
				
				//for splitLine[1], getting R1
				if(splitLine[1].charAt(0) == 'R'){
					R1 = Short.parseShort(splitLine[1].substring(1));
					if(R1 < 0 || R1 > 63)
						throw new InvalidRegisterException("This register doesn't exist");
				}
				else
					throw new InvalidRegisterException("This register doesn't exist");
				
				
				//for splitLine[2], getting R2 or Immediate value depending on the instruction type
				if((opcode >= 0 && opcode <= 2) || (opcode >= 5 && opcode <= 7)){
					if(splitLine[2].charAt(0) == 'R'){
						R2 = Short.parseShort(splitLine[2].substring(1));
						if(R2 < 0 || R2 > 63)
							throw new InvalidRegisterException("This register doesn't exist");
					}
					else
						throw new InvalidRegisterException("This register doesn't exist");
					
					//concatenating all bits for opcode, R1, R2
					opcode = (short) (opcode << 12);
					R1 = (short) (R1 << 6);
					instruction = (short) (opcode + R1 + R2);
					instructions.instructionMemory.set(numberOfInstructions,instruction);
				}
				else{
					immediate = Short.parseShort(splitLine[2]);
					
					//concatenating all bits for opcode, R1, immediate
					
					String opcodeBinary = "";
					String R1Binary = "";
					String immBinary = "";
					String instructionBinary = "";
					
					while(opcode > 0){
						opcodeBinary =  ( (opcode % 2 ) == 0 ? "0" : "1") + opcodeBinary;
				        opcode = (short) (opcode / 2);
					}
					
					while(R1 > 0){
						R1Binary =  ( (R1 % 2 ) == 0 ? "0" : "1") + R1Binary;
				        R1 = (short) (R1 / 2);
					}
					while(R1Binary.length()!=6)
						R1Binary = "0" + R1Binary;
					
					if(immediate >= 0){
						while(immediate > 0){
							immBinary =  ( (immediate % 2 ) == 0 ? "0" : "1") + immBinary;
					        immediate = (short) (immediate / 2);
						}
						while(immBinary.length()!=6)
							immBinary = "0" + immBinary;
						}
					else{
						//System.out.println(immediate);
						immediate = (short) ((~immediate) + 1);
						//System.out.println(immediate);

						while(immediate > 0){
							immBinary =  ( (immediate % 2 ) == 0 ? "0" : "1") + immBinary;
					        immediate = (short) (immediate / 2);
						}
						
						//System.out.println(immBinary);
						
						while(immBinary.length()!=6)
							immBinary = "0" + immBinary;
						
						String negativeImm = "";
						for(int i = 0; i<immBinary.length();i++){
							if(immBinary.charAt(i) == '0')
								negativeImm += '1';
							else
								negativeImm += '0';
						}
						
						//System.out.println(negativeImm);
						
						immBinary = "";
						int stop = 0;
						for(int i = negativeImm.length()-1; i >= 0; i--){
							System.out.println(negativeImm.charAt(i));
							if(negativeImm.charAt(i) == '0'){
								immBinary = "1" + immBinary;
								stop = i-1;
								i = -1;
							}
							else immBinary = "0" + immBinary;
						}
						//System.out.println(immBinary);
						
						while(stop >= 0)
							immBinary = (negativeImm.charAt(stop--)) + immBinary;
						
						//System.out.println(Integer.parseInt(immBinary,2));
						
					}
										
					instructionBinary = opcodeBinary + R1Binary + immBinary;
					
					instruction = (short) Integer.parseInt(instructionBinary,2);
					instructions.instructionMemory.set(numberOfInstructions,instruction);
				}
				numberOfInstructions++;
		    }
			myReader.close();
		}
		catch (FileNotFoundException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}
	
	public void fetch(){
		if(instructions.instructionMemory.get(pc) == null){
			System.out.println("There is no instruction in the Instruction Fetch stage" + "\n");
			pipeline.pipelineRegisters.set(0,null);
		}
		else{
			Short inst = instructions.instructionMemory.get(pc);
			short[] fetchedInst = new short[2];
			fetchedInst[0] = pc;
			fetchedInst[1] = inst;
			System.out.println("Instruction Fetch Stage:" + "\n" + "Instruction: " + currentProgram.get(pc) + getIntsructionType(inst));
			System.out.println("Parsed Instruction in Instruction Memory: " + inst + "\n");
			
			pipeline.pipelineRegisters.set(0, fetchedInst);
			pc++;
		}
	}
	
	public void decode(){
		
		if(pipeline.pipelineRegisters.get(1) == null){
			System.out.println("There is no instruction in the Instruction Decode stage" + "\n");
			pipeline.pipelineRegisters.set(1,pipeline.pipelineRegisters.get(0));
		}
		else{
			byte opcode, R1, R2, immediate;
			byte[] decodeValues = new byte[6];
			Short instruction = (pipeline.pipelineRegisters.get(1))[1];
			
			System.out.println("Instruction Decode Stage:" + "\n" + "Instruction: " + currentProgram.get((pipeline.pipelineRegisters.get(1))[0]) + getIntsructionType(instruction));
			System.out.println("Parsed Instruction in Instruction Memory: " + instruction + "\n");
			
			opcode = (byte) ((instruction & 0b1111000000000000) >> 12);
			decodeValues[0] = opcode;
			
			R1 = (byte) ((instruction & 0b0000111111000000) >> 6);
			decodeValues[1] = R1;
			decodeValues[2] = registers.registerFile.get(R1);
					
			System.out.println("Decoded Values:" + "\n" + "Opcode: " + decodeValues[0] + "\n" + 
					"Operation Name: " + operationName(decodeValues[0]) + "\n" +
					"Destination Register: R" + decodeValues[1] + "\n" +
					"Destination Register Initial Value: " + decodeValues[2] + "\n");
			
			if((opcode >= 0 && opcode <= 2) || (opcode >= 5 && opcode <= 7)){
				R2 = (byte) (instruction & 0b0000000000111111);
				decodeValues[3] = R2;
				decodeValues[4] = (byte) registers.registerFile.get(R2);
				decodeValues[5] = 0;
				System.out.println("Source Register: R" + decodeValues[3] + "\n" + "Source Register Value: " + decodeValues[4] + "\n");
				System.out.println("Immediate Value: Not applicable" + "\n");
			}
			else{
				immediate = ((byte) (instruction & 0b0000000000111111));
				decodeValues[3] = 0;
				decodeValues[4] = 0;
				
				String immBinary = "";
				while(immediate > 0){
					immBinary =  ( (immediate % 2 ) == 0 ? "0" : "1") + immBinary;
			        immediate = (byte) (immediate / 2);
				}
				
				//System.out.println(immBinary);
				
				while(immBinary.length()!=6)
					immBinary = "0" + immBinary;
				
				if(immBinary.charAt(0) == '1'){
					String negativeImm = "";
					for(int i = 0; i<immBinary.length();i++){
						if(immBinary.charAt(i) == '0')
							negativeImm += '1';
						else
							negativeImm += '0';
					}
					
					//System.out.println(negativeImm);

					immBinary = "";
					int stop = 0;
					for(int i = negativeImm.length()-1; i >= 0; i--){
						if(negativeImm.charAt(i) == '0'){
							immBinary = "1" + immBinary;
							stop = i-1;
							i = -1;
						}
						else immBinary = "0" + immBinary;
					}
					
					//System.out.println(immBinary);
					
					while(stop >= 0)
						immBinary = (negativeImm.charAt(stop--)) + immBinary;
					
					//System.out.println(immBinary);

					
					immediate = (byte) (((Integer.parseInt(immBinary,2))*-1));
				}
				else
					immediate = (byte) Integer.parseInt(immBinary,2);
				
				decodeValues[5] = immediate;
				System.out.println("Source Register: Not applicable" + "\n" + "Source Register Value: Not applicable" + "\n");
				System.out.println("Immediate Value: " + decodeValues[5] + "\n");
			}
			
			short[] decodedValues = new short[6];
			for(int i = 0; i < 6; i++)
				decodedValues[i] = (short)decodeValues[i];
			
			if(pipeline.pipelineRegisters.get(2) != null && pipeline.pipelineRegisters.get(3) != null)
				pipeline.pipelineRegisters.set(2, pipeline.pipelineRegisters.get(1));
			
			
			pipeline.pipelineRegisters.set(1,pipeline.pipelineRegisters.get(0));
			pipeline.pipelineRegisters.set(4, decodedValues);
			
			
		}
	}
	
	public void execute() throws InvalidImmediateValueException{
		
		if(pipeline.pipelineRegisters.get(2) == null){
			System.out.println("There is no instruction in the Execute stage" + "\n");
			pipeline.pipelineRegisters.set(2,pipeline.pipelineRegisters.get(1));
		}
		else if(pipeline.pipelineRegisters.get(3) == null){
			System.out.println("There is no instruction in the Execute stage" + "\n");
			pipeline.pipelineRegisters.set(3,pipeline.pipelineRegisters.get(2));
			pipeline.pipelineRegisters.set(5,pipeline.pipelineRegisters.get(4));
		}
		else{
			Short instruction = (pipeline.pipelineRegisters.get(3))[1];
			short pcStored = (pipeline.pipelineRegisters.get(3))[0];
			short[] decodeValues = pipeline.pipelineRegisters.get(5);
			
			byte result = 0;
			byte opcode = (byte) decodeValues[0];
			byte R1location = (byte) decodeValues[1];
			byte R1value = (byte) decodeValues[2];
			byte R2location = (byte) decodeValues[3];
			byte R2value = (byte) decodeValues[4];
			byte immediate = (byte) decodeValues[5];
			byte unsignedR1, unsignedR2, unsignedMSB, msb;
			byte unsignedResult;
			boolean pcChanged = false;
			
			//Status Register : 000CVNSZ
			byte carryFlag = 0; //C flag
			byte overflowFlag = 0; //V flag
			byte negativeFlag = 0; //N flag
			byte signFlag = 0;  //S flag
			byte zeroFlag = 0; //Z flag
	
			switch(opcode){
			// ADD R1 R2......... R1=R1+R2
			case 0: result = (byte) (R1value + R2value);
					unsignedR1 = (byte) ((~R1value) + 1);
					unsignedR2 = (byte) ((~R2value) + 1);
					unsignedResult = (byte) (unsignedR1 + unsignedR2);
					unsignedMSB = (byte) ((unsignedResult & 0b10000000) >> 7);
					carryFlag = unsignedMSB;
					if((R1value >= 0 && R2value >= 0 && result < 0) || (R1value<0 && R2value<0 && result >= 0))
						overflowFlag = 1;
					msb = (byte) ((result & 0b10000000) >> 7);
					negativeFlag = msb;
					signFlag = (byte) (negativeFlag^overflowFlag);
					if(result == 0)
						zeroFlag = 1;
					registers.registerFile.set(decodeValues[1],result);
					break;
					
			//SUB R1 R2 ........R1=R1-R2
			case 1: result = (byte) (R1value - R2value);
					if((R1value >= 0 && R2value<0 && result < 0) || (R1value<0 && R2value>=0 && result>=0))
						overflowFlag = 1;
					msb = (byte) ((result & 0b10000000) >> 7);
					negativeFlag = msb;
					signFlag = (byte) (negativeFlag^overflowFlag);
					if(result == 0)
						zeroFlag = 1;
					registers.registerFile.set(decodeValues[1],result);
					break;
					
			//MUL R1 R2.............. R1=R1*R2
			case 2: result = (byte) (R1value * R2value);
					msb = (byte) ((result & 0b10000000) >> 7);
					negativeFlag = msb;
					if(result == 0)
						zeroFlag = 1;
					registers.registerFile.set(decodeValues[1],result);
					break;
			
			//LDI R1 IMM...............R1=IMM		
			case 3: result = immediate; 
					registers.registerFile.set(decodeValues[1],result);break;
			
			//BEQZ R1 IMM........... IF(R1 == 0) {PC = PC+1+IMM }
			case 4: if(R1value == 0){
						pcChanged = true;
						pc = (short) (pcStored + 1 + immediate);
						pipeline.pipelineRegisters.set(0,null);
						pipeline.pipelineRegisters.set(1,null);
						pipeline.pipelineRegisters.set(2,null);
						pipeline.pipelineRegisters.set(3,null);
					}
					break;
					
			//AND R1 R2.............R1=R1&R2
			case 5: result = (byte) (R1value & R2value);
					msb = (byte) ((result & 0b10000000) >> 7);
					negativeFlag = msb;
					if(result == 0)
						zeroFlag = 1;
					registers.registerFile.set(decodeValues[1],result);
					break;
			
			//OR R1 R2............... R1=R1|R2
			case 6: result = (byte) (R1value | R2value);
					msb = (byte) ((result & 0b10000000) >> 7);
					negativeFlag = msb;
					if(result == 0)
						zeroFlag = 1;
					registers.registerFile.set(decodeValues[1],result);
					break;
					
			//JR R1 R2........ Concatenate R1 with R2 in PC
			case 7: pc = concatenate(R1value,R2value);
					if(pc != pcStored)
						pcChanged = true;
					pipeline.pipelineRegisters.set(0,null);
					pipeline.pipelineRegisters.set(1,null);
					pipeline.pipelineRegisters.set(2,null);
					pipeline.pipelineRegisters.set(3,null);
					break;
					
			//SLC R1 IMM.............. R1 = R1 << IMM | R1 >>> 8 - IMM
			case 8: if(immediate >= 0){
						result = (byte) ((R1value << immediate) | (R1value >>> (8-immediate)));
						msb = (byte) ((result & 0b10000000) >> 7);
						negativeFlag = msb;
						if(result == 0)
							zeroFlag = 1;
						registers.registerFile.set(decodeValues[1],result);
					}
					else
						throw new InvalidImmediateValueException("Immediate value for shifting operations must be a positive number");
					break;
					
			//SRC R1 IMM.................. R1 = R1 >>> IMM | R1 << 8 - IMM
			case 9: if(immediate >= 0){
						result = (byte) ((R1value >>> immediate) | (R1value << (8-immediate)));
						msb = (byte) ((result & 0b10000000) >> 7);
						negativeFlag = msb;
						if(result == 0)
							zeroFlag = 1;
						registers.registerFile.set(decodeValues[1],result);
					}
					else
						throw new InvalidImmediateValueException("Immediate value for shifting operations must be a positive number");
					break;
			
			//LB R1 ADDRESS.............R1 = MEM[ADDRESS]		
			case 10: result = data.dataMemory.get(immediate);
					registers.registerFile.set(decodeValues[1],result);break;
			
			//SB R1 ADDRESS..............MEM[ADDRESS] = R1
			case 11: data.dataMemory.set(immediate, R1value);;break;
			
			default: result = 0;
					carryFlag = 0;
					overflowFlag = 0;
					negativeFlag = 0;
					signFlag = 0; 
					zeroFlag = 0;
			}
			
			
			System.out.println("Execute Stage:" + "\n" + "Instruction: " + currentProgram.get(pcStored) + getIntsructionType(instruction)+ "\n" +
					"Parsed Instruction in Instruction Memory: " + instruction + "\n");
			System.out.println("Its Decoded Values and Updated Registers:" + "\n" + "Opcode: " + decodeValues[0] + "\n" + 
						"Operation Name: " + operationName(opcode) + "\n" +
						"Destination Register: R" + decodeValues[1] + "\n" +
						"Destination Register Initial Value: " + decodeValues[2] + "\n");
			
			if((opcode >= 0 && opcode <= 2) || (opcode >= 5 && opcode <= 7))
				System.out.println("Source Register: R" + decodeValues[3] + "\n" + "Source Register Value: " + decodeValues[4] + "\n" + 
						"Immediate Value: Not applicable" + "\n" + "\n");
			else
				System.out.println("Source Register: Not applicable" + "\n" + "Source Register Value: Not applicable" + "\n" + "\n" + 
								"Immediate Value: " + decodeValues[5] + "\n");
			
			if(opcode == 10){
				System.out.println("Value of R" + decodeValues[1] + " is loaded from MEM[" + decodeValues[5] + "]");
				System.out.println("Destination Register R" + decodeValues[1] + " is updated to: " + result);
			}
			else if(opcode == 11)
				System.out.println("Value of R" + decodeValues[1] + " is stored in MEM[" + decodeValues[5] + "]" + "\n" +
									"Memory Address " + decodeValues[5] + " is updated to: " + result);
			else if(opcode == 4 || opcode == 7){
				if(pcChanged)
					System.out.println("PC value is updated to: " + pc);
				else
					System.out.println("PC value did not change");
			}
			else
				System.out.println("Destination Register R" + decodeValues[1] + " is updated to: " + result);
			
			System.out.println("Status Register: 000" + carryFlag + overflowFlag + negativeFlag + signFlag + zeroFlag + "\n" + "\n");
			
			// concatenation el flags (Status Register : 000CVNSZ) + rewrite result in R1
			
			carryFlag = (byte) (carryFlag << 4);
			overflowFlag = (byte) (overflowFlag << 3);
			negativeFlag = (byte) (negativeFlag << 2);
			signFlag = (byte) (signFlag << 1); 
			SREG = (byte) (carryFlag + overflowFlag + negativeFlag + signFlag + zeroFlag);
			
			pipeline.pipelineRegisters.set(3,pipeline.pipelineRegisters.get(2));
			if(pipeline.pipelineRegisters.get(4) != null)
				pipeline.pipelineRegisters.set(5,pipeline.pipelineRegisters.get(4));
			else if(instructions.instructionMemory.get(pc) == null)
				pipeline.pipelineRegisters.set(5,pipeline.pipelineRegisters.get(4));
			
			if(pcChanged && instructions.instructionMemory.get(pc) == null)
				pipeline.pipelineRegisters.set(5,null);
			
			if(pipeline.pipelineRegisters.get(0) == null && pipeline.pipelineRegisters.get(1) == null)
				pipeline.pipelineRegisters.set(4,null);
	
		}
	}
	
	public short concatenate (byte R1, byte R2){
		String R1Binary = "";
		String R2Binary = "";
		String resultBinary = "";
		
		if(R1 >= 0){
			while(R1 > 0){
				R1Binary =  ( (R1 % 2 ) == 0 ? "0" : "1") + R1Binary;
		        R1 = (byte) (R1 / 2);
			}
			while(R1Binary.length()!=8)
				R1Binary = "0" + R1Binary;
			}
		else{
			R1 = (byte) ((~R1) + 1);

			while(R1 > 0){
				R1Binary =  ( (R1 % 2 ) == 0 ? "0" : "1") + R1Binary;
		        R1 = (byte) (R1 / 2);
			}
			
			
			while(R1Binary.length()!=8)
				R1Binary = "0" + R1Binary;
			
			String negativeImm = "";
			for(int i = 0; i<R1Binary.length();i++){
				if(R1Binary.charAt(i) == '0')
					negativeImm += '1';
				else
					negativeImm += '0';
			}
						
			R1Binary = "";
			int stop = 0;
			for(int i = negativeImm.length()-1; i >= 0; i--){
				System.out.println(negativeImm.charAt(i));
				if(negativeImm.charAt(i) == '0'){
					R1Binary = "1" + R1Binary;
					stop = i-1;
					i = -1;
				}
				else R1Binary = "0" + R1Binary;
			}
			//System.out.println(immBinary);
			
			while(stop >= 0)
				R1Binary = (negativeImm.charAt(stop--)) + R1Binary;
						
		}
		
		if(R2 >= 0){
			while(R2 > 0){
				R2Binary =  ( (R2 % 2 ) == 0 ? "0" : "1") + R2Binary;
		        R2 = (byte) (R2 / 2);
			}
			while(R2Binary.length()!=8)
				R2Binary = "0" + R2Binary;
			}
		else{
			R2 = (byte) ((~R2) + 1);

			while(R2 > 0){
				R2Binary =  ( (R2 % 2 ) == 0 ? "0" : "1") + R2Binary;
		        R2 = (byte) (R2 / 2);
			}
			
			
			while(R2Binary.length()!=8)
				R2Binary = "0" + R2Binary;
			
			String negativeImm = "";
			for(int i = 0; i<R2Binary.length();i++){
				if(R2Binary.charAt(i) == '0')
					negativeImm += '1';
				else
					negativeImm += '0';
			}
						
			R2Binary = "";
			int stop = 0;
			for(int i = negativeImm.length()-1; i >= 0; i--){
				System.out.println(negativeImm.charAt(i));
				if(negativeImm.charAt(i) == '0'){
					R2Binary = "1" + R2Binary;
					stop = i-1;
					i = -1;
				}
				else R2Binary = "0" + R2Binary;
			}
			
			while(stop >= 0)
				R2Binary = (negativeImm.charAt(stop--)) + R2Binary;
						
		}
							
		resultBinary = R1Binary + R2Binary;
		
		return (short) Integer.parseInt(resultBinary,2);
	}
	
	public String operationName(byte decodeValues){
		String name;
		switch(decodeValues){
		case 0: name = "Add"; break;
		case 1: name = "Subtract"; break;
		case 2: name = "Multply"; break;
		case 3: name = "Load Immediate"; break;
		case 4: name = "Branch if Equal Zero"; break;
		case 5: name = "And"; break;
		case 6: name = "Or"; break;
		case 7: name = "Jump Register"; break;
		case 8: name = "Shift Left Circular"; break;
		case 9: name = "Shift Right Circular"; break;
		case 10: name = "Load Byte"; break;
		case 11: name = "Store Byte"; break;
		default: name = "";
		}
		return name;
	}
	
	public String getIntsructionType(short instruction){
		byte opcode = (byte) ((instruction & 0b1111000000000000) >> 12);
		if((opcode >= 0 && opcode <= 2) || (opcode >= 5 && opcode <= 7))
			return " (R-Format)";
		else
			return " (I-Format)";
	}
	
	public void runProgram(ArrayList<String> program) throws InvalidImmediateValueException{
		
		int currentClockCycle = 1;
		Boolean stopExecute = true;
		while(stopExecute){
			
			System.out.println("Clock Cycle Number: " + currentClockCycle);
			
				fetch();
				decode();
				execute();
						
			if((pipeline.pipelineRegisters.get(0) == null && pipeline.pipelineRegisters.get(1) == null && pipeline.pipelineRegisters.get(5) == null)){
				stopExecute = false;
				System.out.println("Program finished in total Clock Cycles = " + currentClockCycle);
			}	
			currentClockCycle++;

			registers.displayRegisters();
			System.out.println("");
		}
		data.displayData();
		instructions.displayInstructions();
		
	}
	
	
	public static void main(String[] args){
		CPU cpu = new CPU();
		try {
			cpu.readFile("test.txt");
			cpu.runProgram(cpu.currentProgram);
		} catch (InvalidRegisterException e) {
			e.printStackTrace();
		} catch (InvalidImmediateValueException e) {
			e.printStackTrace();
		}
			
	}
}
